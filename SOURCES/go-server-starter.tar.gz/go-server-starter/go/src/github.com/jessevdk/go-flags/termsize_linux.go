// +build linux

package flags

const (
	tIOCGWINSZ = 0x5413
)
