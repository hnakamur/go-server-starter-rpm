#!/bin/bash

set -e

docker build -t server_starter-docker .